# Практическая работа 2 — WPF-калькулятор

Решение разделено на три проекта: `KoshechkinCalculatorLib` (вычислительная логика), `KoshechkinCalculatorApp` (WPF-интерфейс) и `KoshechkinCalculatorTests` (MSTest). Движок использует рекурсивный спуск, поддерживает приоритет операций, скобки, десятичные числа и правую ассоциативность возведения в степень. Сопроводительная записка в PDF — `Report.pdf`.

## Открытие и запуск

Откройте `KoshechkinCalculator.sln` в Visual Studio 2022 с установленной поддержкой .NET Desktop Development и .NET 8.

```powershell
dotnet test KoshechkinCalculatorTests/KoshechkinCalculatorTests.csproj
dotnet run --project KoshechkinCalculatorApp/KoshechkinCalculatorApp.csproj
```

Отчёт находится в `Report.pdf`. Внесите ФИО и группу, а также замените схематичные иллюстрации реальными снимками экрана приложения и Обозревателя тестов после запуска.
